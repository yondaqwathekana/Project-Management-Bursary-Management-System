document.addEventListener("DOMContentLoaded", function() {
    const bursaries = [
        { id: 1, name: "Bursary 1", description: "Description of Bursary 1", eligibility: "Postgraduate", requirements: "Requirement details for Bursary 1" },
        { id: 2, name: "Bursary 2", description: "Description of Bursary 2", eligibility: "Undergraduate", requirements: "Requirement details for Bursary 2" },
        { id: 3, name: "Bursary 3", description: "Description of Bursary 3", eligibility: "High School", requirements: "Requirement details for Bursary 3" },
        { id: 4, name: "Bursary 4", description: "Description of Bursary 4", eligibility: "Postgraduate", requirements: "Requirement details for Bursary 4" },
        { id: 5, name: "Bursary 5", description: "Description of Bursary 5", eligibility: "Undergraduate", requirements: "Requirement details for Bursary 5" },
        { id: 6, name: "Bursary 6", description: "Description of Bursary 6", eligibility: "High School", requirements: "Requirement details for Bursary 6" }
    ];

    const bursaryList = document.getElementById("bursaryList");

    function createBursaryElement(bursary, colorClass) {
        const bursaryDiv = document.createElement("div");
        bursaryDiv.className = `bursary ${colorClass}`;
        
        const bursaryInfo = document.createElement("p");
        bursaryInfo.className = "bursary-info";
        bursaryInfo.textContent = `${bursary.name}: ${bursary.description}`;
        bursaryDiv.appendChild(bursaryInfo);
        
        const bursaryDetails = document.createElement("div");
        bursaryDetails.className = "bursary-details";
        bursaryDetails.innerHTML = `
            <p><strong>Eligibility:</strong> ${bursary.eligibility}</p>
            <p><strong>Requirements:</strong> ${bursary.requirements}</p>
            <button class="applyButton">Apply</button>
        `;
        bursaryDiv.appendChild(bursaryDetails);

        bursaryDiv.addEventListener("click", function() {
            bursaryDiv.classList.toggle("active");
        });

        bursaryList.appendChild(bursaryDiv);
    }

    const colorClasses = ['color1', 'color2', 'color3', 'color4', 'color5', 'color6'];

    bursaries.forEach((bursary, index) => {
        const colorClass = colorClasses[index % colorClasses.length];
        createBursaryElement(bursary, colorClass);
    });
});
